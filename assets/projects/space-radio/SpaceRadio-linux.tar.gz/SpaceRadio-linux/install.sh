#!/bin/bash
# =============================================================================
#  SpaceRadio для України — Linux Installer
#  Version: 0.3.1
# =============================================================================
#
#  ЗАПУСК:
#    chmod +x install.sh
#    ./install.sh
#
#  Підтримувані дистрибутиви: Debian, Ubuntu, Fedora, Arch, openSUSE
# =============================================================================

set -euo pipefail

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; BOLD='\033[1m'; NC='\033[0m'
info()    { echo -e "${CYAN}[INFO]${NC}  $*"; }
success() { echo -e "${GREEN}[OK]${NC}    $*"; }
warn()    { echo -e "${YELLOW}[WARN]${NC}  $*"; }
error()   { echo -e "${RED}[ERROR]${NC} $*" >&2; }
step()    { echo -e "\n${BOLD}==> $*${NC}"; }

INSTALL_DIR="${HOME}/SpaceRadio"
VENV_DIR="${INSTALL_DIR}/venv"
LAUNCHER="${INSTALL_DIR}/launch_spaceradio.sh"
DESKTOP_FILE="${HOME}/.local/share/applications/spaceradio.desktop"
MIN_PYTHON_MINOR=11

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SRC_DIR="${SCRIPT_DIR}/SpaceRadio-src"

echo ""
echo -e "${BOLD}${CYAN}"
echo "  ╔══════════════════════════════════════════════════════════════╗"
echo "  ║          SpaceRadio для України — Linux Installer            ║"
echo "  ║                       Version 0.3.1                         ║"
echo "  ╚══════════════════════════════════════════════════════════════╝"
echo -e "${NC}"

# ── Перевірка вихідного коду ─────────────────────────────────────────────── #
step "Перевірка вихідного коду"
if [[ ! -d "${SRC_DIR}" || ! -f "${SRC_DIR}/pyproject.toml" ]]; then
    error "SpaceRadio-src/ не знайдено поруч із install.sh"
    error "Переконайтесь що архів розпаковано повністю."
    exit 1
fi
success "Вихідний код знайдено: ${SRC_DIR}"

# ── Визначення дистрибутива ──────────────────────────────────────────────── #
step "Визначення дистрибутива Linux"
if command -v apt &>/dev/null; then
    DISTRO="debian"
    success "Debian/Ubuntu (apt)"
elif command -v dnf &>/dev/null; then
    DISTRO="fedora"
    success "Fedora/RHEL (dnf)"
elif command -v pacman &>/dev/null; then
    DISTRO="arch"
    success "Arch Linux (pacman)"
elif command -v zypper &>/dev/null; then
    DISTRO="suse"
    success "openSUSE (zypper)"
else
    DISTRO="unknown"
    warn "Дистрибутив не визначено. Встановіть залежності вручну."
fi

# ── Системні залежності ──────────────────────────────────────────────────── #
step "Встановлення системних залежностей"
case "${DISTRO}" in
debian)
    sudo apt update -qq
    sudo apt install -y python3-pip python3-venv python3-tk \
        libusb-1.0-0 libusb-1.0-0-dev cmake git build-essential \
        rtl-sdr librtlsdr-dev pkg-config
    ;;
fedora)
    sudo dnf install -y python3-pip python3-tkinter \
        libusb libusb-devel cmake git gcc \
        rtl-sdr rtl-sdr-devel pkgconf
    ;;
arch)
    sudo pacman -Sy --noconfirm python-pip tk \
        libusb cmake git base-devel \
        rtl-sdr
    ;;
suse)
    sudo zypper install -y python3-pip python3-tk \
        libusb-1_0-0 libusb-1_0-devel cmake git gcc \
        rtl-sdr
    ;;
*)
    warn "Встановіть вручну: python3, pip, libusb, rtl-sdr, cmake, git"
    ;;
esac
success "Системні залежності встановлено."

# ── Перевірка librtlsdr v5 ───────────────────────────────────────────────── #
step "Перевірка сумісності librtlsdr з RTL-SDR v5"

check_rtlsdr_v5() {
    python3 -c "
import ctypes, sys
for lib_name in ['librtlsdr.so', 'librtlsdr.so.0', 'librtlsdr.so.2']:
    try:
        lib = ctypes.CDLL(lib_name)
        _ = lib.rtlsdr_set_dithering
        print('OK')
        sys.exit(0)
    except Exception:
        continue
sys.exit(1)
" 2>/dev/null
}

build_rtlsdr_from_source() {
    info "Збірка librtlsdr з вихідного коду (потрібна для RTL-SDR v5)..."
    local TMPDIR
    TMPDIR=$(mktemp -d)
    git clone https://github.com/librtlsdr/librtlsdr.git "${TMPDIR}" --depth=1
    cmake -S "${TMPDIR}" -B "${TMPDIR}/build" \
        -DCMAKE_BUILD_TYPE=Release \
        -DINSTALL_UDEV_RULES=OFF
    make -C "${TMPDIR}/build" -j"$(nproc)"
    sudo make -C "${TMPDIR}/build" install
    sudo ldconfig
    rm -rf "${TMPDIR}"
    success "librtlsdr зібрано та встановлено."
}

if check_rtlsdr_v5; then
    success "librtlsdr v5-сумісна."
else
    warn "librtlsdr відсутня або стара. Збираємо з вихідного коду..."
    build_rtlsdr_from_source || warn "Збірка не вдалась — тільки --mock режим."
fi

# ── udev правила для RTL-SDR ────────────────────────────────────────────── #
step "Налаштування udev для RTL-SDR (без sudo не читає USB)"
if [[ -f /etc/udev/rules.d/rtl-sdr.rules ]] || [[ -f /lib/udev/rules.d/rtl-sdr.rules ]]; then
    success "udev правила вже налаштовано."
else
    cat << 'UDEV' | sudo tee /etc/udev/rules.d/rtl-sdr.rules > /dev/null
SUBSYSTEM=="usb", ATTRS{idVendor}=="0bda", ATTRS{idProduct}=="2832", GROUP="plugdev", MODE="0666", SYMLINK+="rtl_sdr"
SUBSYSTEM=="usb", ATTRS{idVendor}=="0bda", ATTRS{idProduct}=="2838", GROUP="plugdev", MODE="0666", SYMLINK+="rtl_sdr"
SUBSYSTEM=="usb", ATTRS{idVendor}=="0bda", ATTRS{idProduct}=="2888", GROUP="plugdev", MODE="0666", SYMLINK+="rtl_sdr"
UDEV
    sudo udevadm control --reload-rules 2>/dev/null || true
    sudo udevadm trigger 2>/dev/null || true
    # Add user to plugdev group
    sudo usermod -aG plugdev "${USER}" 2>/dev/null || true
    success "udev правила встановлено. Перепідключіть донгл після встановлення."
fi

# ── Python ───────────────────────────────────────────────────────────────── #
step "Пошук Python 3.${MIN_PYTHON_MINOR}+"

find_python() {
    for cmd in python3.12 python3.11 python3; do
        command -v "${cmd}" &>/dev/null || continue
        local maj ver
        maj=$("${cmd}" -c "import sys; print(sys.version_info.major)" 2>/dev/null) || continue
        ver=$("${cmd}" -c "import sys; print(sys.version_info.minor)" 2>/dev/null) || continue
        [[ "${maj}" -eq 3 && "${ver}" -ge ${MIN_PYTHON_MINOR} ]] && echo "${cmd}" && return 0
    done
    return 1
}

if PYTHON_CMD=$(find_python); then
    success "Знайдено: $("${PYTHON_CMD}" --version)"
else
    error "Python 3.${MIN_PYTHON_MINOR}+ не знайдено. Встановіть через менеджер пакетів."
    exit 1
fi

# ── Віртуальне середовище та встановлення ────────────────────────────────── #
step "Створення Python-середовища"
mkdir -p "${INSTALL_DIR}"
if [[ -d "${VENV_DIR}" ]]; then
    warn "Існуюче venv знайдено."
    read -r -p "  Перестворити? [y/N] " REPLY; echo ""
    [[ "${REPLY}" =~ ^[Yy]$ ]] && rm -rf "${VENV_DIR}"
fi
[[ ! -d "${VENV_DIR}" ]] && "${PYTHON_CMD}" -m venv "${VENV_DIR}" && success "venv створено."

source "${VENV_DIR}/bin/activate"
VENV_PIP="${VENV_DIR}/bin/pip"
VENV_PYTHON="${VENV_DIR}/bin/python"

"${VENV_PIP}" install --upgrade pip setuptools wheel build

step "Встановлення SpaceRadio"
"${VENV_PIP}" install "${SRC_DIR}"
success "SpaceRadio встановлено."

step "Встановлення Python-бібліотеки RTL-SDR"
"${VENV_PIP}" install pyrtlsdr pyrtlsdrlib || warn "pyrtlsdr не вдалось — тільки --mock режим."

"${VENV_PYTHON}" -c "import skao_trt; print('[OK] importe успішний')" && success "OK." || warn "Перевірка неоднозначна."

# ── Лаунчер ──────────────────────────────────────────────────────────────── #
step "Створення лаунчера"
cat > "${LAUNCHER}" << LAUNCHER_SCRIPT
#!/bin/bash
source "${VENV_DIR}/bin/activate"
EXTRA_ARGS="\$@"
if [[ "\${EXTRA_ARGS}" != *"--no-mock"* && "\${EXTRA_ARGS}" != *"--mock"* ]]; then
  echo "[SpaceRadio] Демо-режим. Для реального обладнання: --no-mock"
  exec skao-trt --language Українська --mock "\$@"
else
  EXTRA_ARGS="\${EXTRA_ARGS//--no-mock/}"
  exec skao-trt --language Українська \${EXTRA_ARGS}
fi
LAUNCHER_SCRIPT
chmod +x "${LAUNCHER}"
success "Лаунчер: ${LAUNCHER}"

# ── .desktop файл для менеджера додатків ─────────────────────────────────── #
step "Створення .desktop ярлика"
mkdir -p "${HOME}/.local/share/applications"
cat > "${DESKTOP_FILE}" << DESKTOP
[Desktop Entry]
Name=SpaceRadio для України
Comment=Космічний радіотелескоп SKAO
Exec=${LAUNCHER}
Icon=${SRC_DIR}/src/skao_trt/img/skao_logo_bar.jpg
Terminal=true
Type=Application
Categories=Education;Science;
DESKTOP
success ".desktop створено: ${DESKTOP_FILE}"

deactivate 2>/dev/null || true

echo ""
echo -e "${BOLD}${GREEN}"
echo "  ╔══════════════════════════════════════════════════════════════╗"
echo "  ║             SpaceRadio встановлено! 🎉                       ║"
echo "  ╚══════════════════════════════════════════════════════════════╝"
echo -e "${NC}"
echo ""
echo -e "${BOLD}  Запуск:${NC}"
echo "    ${LAUNCHER}           # демо-режим"
echo "    ${LAUNCHER} --no-mock  # реальне обладнання"
echo ""
echo -e "${BOLD}  Або через меню додатків:${NC} SpaceRadio для України"
echo ""
echo -e "${YELLOW}  Увага:${NC} Якщо донгл не розпізнається — вийдіть і увійдіть знову"
echo "  (потрібно для застосування udev правил групи plugdev)."
echo ""
