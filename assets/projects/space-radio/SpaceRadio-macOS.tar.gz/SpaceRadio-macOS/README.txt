╔══════════════════════════════════════════════════════════╗
║         SpaceRadio для України — macOS                   ║
║         Космічне Радіо · v0.3.1                          ║
╚══════════════════════════════════════════════════════════╝

ВМІСТ АРХІВУ
────────────
  install.sh        ← запустіть цей файл для встановлення
  SpaceRadio-src/   ← вихідний код (не видаляйте до встановлення)
  README.txt        ← цей файл

ВСТАНОВЛЕННЯ
────────────
  1. Відкрийте Термінал
  2. Перейдіть до папки з розпакованим архівом:
       cd ~/Downloads/SpaceRadio-macOS
  3. Запустіть інсталятор:
       chmod +x install.sh
       ./install.sh

ЗАПУСК
──────
  Демо-режим (без обладнання):
    ~/SpaceRadio/launch_spaceradio.sh

  Реальний телескоп:
    ~/SpaceRadio/launch_spaceradio.sh --no-mock

  Або двічі клацніть SpaceRadio.command у ~/SpaceRadio/

ОБЛАДНАННЯ
──────────
  • RTL-SDR v5 USB-донгл
  • Sawbird+ HI малошумний підсилювач (1420 МГц)
  • Рупорна антена

  Частота спостереження: 1420.4 МГц (лінія водню HI)

КОНТАКТ
───────
  Pavlo Plotko · pavlo.plotko@dzastro.de
  DZA · DESY · SKAO · УАА · МАН України

  https://gitlab.com/ska-telescope/ska-tabletop-radiotelescope
