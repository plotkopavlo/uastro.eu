from enum import StrEnum
from typing import Final


class English(StrEnum):
    STATUS = "Status"
    READY = "Ready"
    PREPARE = "Prepare"
    OBSERVE = "Observe"
    EXIT = "Exit"

    WELCOME_TITLE = "SKAO Table-top Radio Telescope (TRT) App"
    WELCOME_L1 = "Short instruction manual:"
    WELCOME_L2 = "1. Prepare"
    WELCOME_L3 = "2. Observe as many times as you want"

    ERROR_TITLE = "Something went wrong"
    ERROR_L1 = "Check status bar and terminal for more information."
    ERROR_RF = "Not enough RF power. Check antenna and LNA connection."
    ERROR_NO_DEVICE = "No RTL-SDR device found"
    ERROR_DEVICE_MSG = "No RTL-SDR device detected. Check USB connection."
    CHECK_DEVICE = "Check: 1) USB cable plugged in  2) librtlsdr installed  3) No other app using device"

    PREP_START_STATUS = "Preparing ..."
    PREP_GAIN_STATUS = "Trying gain"
    PREP_BASELINE_STATUS = "Recording baseline power spectrum ..."
    PREP_DONE_STATUS = "Preparation complete!"

    PREP_STEP1_TITLE = "Preparation in progress"
    PREP_STEP1_L1 = "This step calibrates your RF device"
    PREP_STEP1_L2 = "Searching for optimal gain ..."

    PREP_STEP2_TITLE = "Preparation in progress"
    PREP_STEP2_L1 = "This step calibrates your RF device"
    PREP_STEP2_L2 = "Searching for optimal gain ... DONE."
    PREP_STEP2_L3 = "Recording baseline power spectrum ..."

    PREP_COMPLETE_TITLE = "Preparation complete"
    PREP_COMPLETE_L1 = "Optimum Gain"
    PREP_COMPLETE_L2 = "You can observe the Milky Way!"
    PREP_COMPLETE_L3 = " - Remove RF termination"
    PREP_COMPLETE_L4 = " - Connect your antenna to the Sawbird HI"
    PREP_COMPLETE_L5 = " - Press Observe"

    OBS_NOT_READY_STATUS = "Please run the preparation step first!"
    OBS_START_STATUS = "Observing ..."
    OBS_PLOT_STATUS = "Plottting ..."
    OBS_DONE_STATUS = "Observation finished!"

    OBSERVE_TITLE = "Sky observation in progress"
    OBSERVE_L1 = "This should take about 30 seconds ..."
    OBSERVE_L2 = "An interactive graph will appear at the end!"

    FIGURE_TITLE = "Hydrogen Line (HI) signal of the Milky Way"
    AXIS_FREQ = "Frequency [MHz]"
    AXIS_INTENSITY = "Intensity [a.u.]"
    ERROR_PREFIX = "Error"


class Afrikaans(StrEnum):
    STATUS = "Status"
    READY = "Gereed"
    PREPARE = "Voorberei"
    OBSERVE = "Observeer"
    EXIT = "Uitgang"

    WELCOME_TITLE = "SKAO Tafelblad Radioteleskoop (TRT) Toep"
    WELCOME_L1 = "Kort handleiding:"
    WELCOME_L2 = "1. Voorberei hardeware vir observasie"
    WELCOME_L3 = "2. Neem observasies soveel keer as wat jy wil"

    ERROR_TITLE = "Iets het verkeerd geloop"
    ERROR_L1 = "Gaan die statusbalk en terminaal na vir meer inligting."
    ERROR_RF = "Nie genoeg RF-krag nie. Kontroleer antenna en LNA-verbinding."
    ERROR_NO_DEVICE = "Geen RTL-SDR toestel gevind"
    ERROR_DEVICE_MSG = "Geen RTL-SDR toestel opgespoor nie. Kontroleer USB-verbinding."
    CHECK_DEVICE = "Kontroleer: 1) USB-kabel ingeprop  2) librtlsdr geïnstalleer  3) Geen ander app gebruik toestel"

    PREP_START_STATUS = "Besig met voorbereiding ..."
    PREP_GAIN_STATUS = "Probeer wins"
    PREP_BASELINE_STATUS = "Neem basislyn kragspektrum op ..."
    PREP_DONE_STATUS = "Voorbereiding voltooi!"

    PREP_STEP1_TITLE = "Voorbereiding aan die gang"
    PREP_STEP1_L1 = "Hierdie stap kalibreer jou RF-toestel"
    PREP_STEP1_L2 = "Soek na optimale wins ..."

    PREP_STEP2_TITLE = "Voorbereiding aan die gang"
    PREP_STEP2_L1 = "Hierdie stap kalibreer jou RF-toestel"
    PREP_STEP2_L2 = "Soek na optimale wins ... VOLTOOI."
    PREP_STEP2_L3 = "Neem basislyn kragspektrum op ..."

    PREP_COMPLETE_TITLE = "Voorbereiding voltooi"
    PREP_COMPLETE_L1 = "Optimale Wins"
    PREP_COMPLETE_L2 = "Jy kan die Melkweg observeer!"
    PREP_COMPLETE_L3 = " - Verwyder RF-beëindiging"
    PREP_COMPLETE_L4 = " - Koppel jou antenna aan die Sawbird HI"
    PREP_COMPLETE_L5 = " - Druk op Observeer"

    OBS_NOT_READY_STATUS = "Voer asseblief eers die voorbereidingstap uit!"
    OBS_START_STATUS = "Besig om te observeer ..."
    OBS_PLOT_STATUS = "Teken grafiek ..."
    OBS_DONE_STATUS = "Observasie voltooi!"

    OBSERVE_TITLE = "Hemelruim observasie aan die gang"
    OBSERVE_L1 = "Dit moet ongeveer 30 sekondes neem ..."
    OBSERVE_L2 = "’n Interaktiewe grafiek sal aan die einde verskyn!"

    FIGURE_TITLE = "Waterstoflyn (HI) sein van die Melkweg"
    AXIS_FREQ = "Frekwensie [MHz]"
    AXIS_INTENSITY = "Intensiteit [w.e.]"
    ERROR_PREFIX = "Fout"


class Chinese(StrEnum):
    STATUS = "状态"
    READY = "准备就绪"
    PREPARE = "准备"
    OBSERVE = "观察"
    EXIT = "退出"

    WELCOME_TITLE = "SKAO 桌面射电望远镜应用程序"
    WELCOME_L1 = "简短使用手册:"
    WELCOME_L2 = "1. 准备"
    WELCOME_L3 = "2. 随意观察多次"

    ERROR_TITLE = "出了点问题"
    ERROR_L1 = "请检查状态栏和终端以获取更多信息。"
    ERROR_RF = "射频功率不足。请检查天线和低噪声放大器的连接。"
    ERROR_NO_DEVICE = "未找到RTL-SDR设备"
    ERROR_DEVICE_MSG = "未检测到RTL-SDR设备。请检查USB连接。"
    CHECK_DEVICE = "检查：1）USB线已插入  2）librtlsdr已安装  3）没有其他应用在使用该设备"

    PREP_START_STATUS = "准备中 ..."
    PREP_GAIN_STATUS = "尝试增益"
    PREP_BASELINE_STATUS = "记录基线功率谱 ..."
    PREP_DONE_STATUS = "准备完成!"

    PREP_STEP1_TITLE = "准备进行中"
    PREP_STEP1_L1 = "此步骤校准您的射频设备"
    PREP_STEP1_L2 = "寻找最佳增益 ..."

    PREP_STEP2_TITLE = "准备进行中"
    PREP_STEP2_L1 = "此步骤校准您的射频设备"
    PREP_STEP2_L2 = "寻找最佳增益 ... 完成。"
    PREP_STEP2_L3 = "记录基线功率谱 ..."

    PREP_COMPLETE_TITLE = "准备完成"
    PREP_COMPLETE_L1 = "最佳增益"
    PREP_COMPLETE_L2 = "您可以观察银河系了!"
    PREP_COMPLETE_L3 = " - 移除射频终端"
    PREP_COMPLETE_L4 = " - 将天线连接到 Sawbird HI"
    PREP_COMPLETE_L5 = " - 按下观察"

    OBS_NOT_READY_STATUS = "请先运行准备步骤!"
    OBS_START_STATUS = "观察中 ..."
    OBS_PLOT_STATUS = "绘制中 ..."
    OBS_DONE_STATUS = "观察完成!"

    OBSERVE_TITLE = "天空观察进行中"
    OBSERVE_L1 = "这大约需要 30 秒 ..."
    OBSERVE_L2 = "最后会出现一个交互式图表!"

    FIGURE_TITLE = "银河系的氢线 (HI) 信号"
    AXIS_FREQ = "频率 [MHz]"
    AXIS_INTENSITY = "强度 [任意单位]"
    ERROR_PREFIX = "错误"


class Dutch(StrEnum):
    STATUS = "Status"
    READY = "Klaar"
    PREPARE = "Voorbereiden"
    OBSERVE = "Observeren"
    EXIT = "Afsluiten"

    WELCOME_TITLE = "SKAO Tafelblad Radiotelescoop (TRT) App"
    WELCOME_L1 = "Korte handleiding:"
    WELCOME_L2 = "1. Voorbereiden"
    WELCOME_L3 = "2. Zo vaak als je wilt observeren"

    ERROR_TITLE = "Er is iets misgegaan"
    ERROR_L1 = "Controleer de statusbalk en terminal voor meer informatie."
    ERROR_RF = "Onvoldoende RF-vermogen. Controleer antenne en LNA-verbinding."
    ERROR_NO_DEVICE = "Geen RTL-SDR apparaat gevonden"
    ERROR_DEVICE_MSG = "Geen RTL-SDR apparaat gedetecteerd. Controleer USB-verbinding."
    CHECK_DEVICE = "Controleren: 1) USB-kabel aangesloten  2) librtlsdr geïnstalleerd  3) Geen andere app gebruikt apparaat"

    PREP_START_STATUS = "Bezig met voorbereiden ..."
    PREP_GAIN_STATUS = "Bezig met gain testen"
    PREP_BASELINE_STATUS = "Baseline vermogensspectrum opnemen ..."
    PREP_DONE_STATUS = "Voorbereiding voltooid!"

    PREP_STEP1_TITLE = "Voorbereiding bezig"
    PREP_STEP1_L1 = "Deze stap kalibreert uw RF-apparaat"
    PREP_STEP1_L2 = "Optimale versterking zoeken ..."

    PREP_STEP2_TITLE = "Voorbereiding bezig"
    PREP_STEP2_L1 = "Deze stap kalibreert uw RF-apparaat"
    PREP_STEP2_L2 = "Optimale versterking zoeken ... VOLTOOID."
    PREP_STEP2_L3 = "Baseline vermogensspectrum opnemen ..."

    PREP_COMPLETE_TITLE = "Voorbereiding voltooid"
    PREP_COMPLETE_L1 = "Optimale versterking"
    PREP_COMPLETE_L2 = "Je kunt de Melkweg observeren!"
    PREP_COMPLETE_L3 = " - Verwijder de RF-terminatie"
    PREP_COMPLETE_L4 = " - Sluit de antenne aan op de Sawbird HI"
    PREP_COMPLETE_L5 = " - Druk op Observeren"

    OBS_NOT_READY_STATUS = "Voer eerst de voorbereidingsstap uit!"
    OBS_START_STATUS = "Bezig met observeren ..."
    OBS_PLOT_STATUS = "Bezig met plotten ..."
    OBS_DONE_STATUS = "Observatie voltooid!"

    OBSERVE_TITLE = "Bezig met hemelobservatie"
    OBSERVE_L1 = "Dit duurt ongeveer 30 seconden ..."
    OBSERVE_L2 = "Aan het einde verschijnt een interactieve grafiek!"

    FIGURE_TITLE = "Waterstoflijn (HI) signaal van de Melkweg"
    AXIS_FREQ = "Frequentie [MHz]"
    AXIS_INTENSITY = "Intensiteit [w.e.]"
    ERROR_PREFIX = "Fout"


class French(StrEnum):
    STATUS = "Statut"
    READY = "Prêt"
    PREPARE = "Préparation"
    OBSERVE = "Observation"
    EXIT = "Quitter"

    WELCOME_TITLE = "Application Table-top Radio Télescope (TRT) du SKAO"
    WELCOME_L1 = "Court manuel d'instructions:"
    WELCOME_L2 = "1. Préparation"
    WELCOME_L3 = "2. Observer autant de fois que vous le souhaitez"

    ERROR_TITLE = "Quelque chose s'est mal passé"
    ERROR_L1 = "Vérifiez la barre d'état et le terminal pour plus d'informations."
    ERROR_RF = "Puissance RF insuffisante. Vérifiez l'antenne et le LNA."
    ERROR_NO_DEVICE = "Aucun appareil RTL-SDR trouvé"
    ERROR_DEVICE_MSG = "Aucun appareil RTL-SDR détecté. Vérifiez la connexion USB."
    CHECK_DEVICE = "Vérifier: 1) Câble USB branché  2) librtlsdr installé  3) Aucune autre app n'utilise l'appareil"

    PREP_START_STATUS = "Préparation en cours ..."
    PREP_GAIN_STATUS = "Test du gain"
    PREP_BASELINE_STATUS = "Enregistrement du spectre de puissance de référence ..."
    PREP_DONE_STATUS = "Préparation terminée!"

    PREP_STEP1_TITLE = "Préparation en cours"
    PREP_STEP1_L1 = "Cette étape calibre votre appareil RF"
    PREP_STEP1_L2 = "Recherche du gain optimal ..."

    PREP_STEP2_TITLE = "Préparation en cours"
    PREP_STEP2_L1 = "Cette étape calibre votre appareil RF"
    PREP_STEP2_L2 = "Recherche du gain optimal ... TERMINÉ."
    PREP_STEP2_L3 = "Enregistrement du spectre de puissance de référence ..."

    PREP_COMPLETE_TITLE = "Préparation terminée"
    PREP_COMPLETE_L1 = "Gain optimal"
    PREP_COMPLETE_L2 = "Vous pouvez observer la Voie Lactée!"
    PREP_COMPLETE_L3 = " - Retirez la terminaison RF"
    PREP_COMPLETE_L4 = " - Connectez votre antenne au Sawbird HI"
    PREP_COMPLETE_L5 = " - Appuyez sur Observation"

    OBS_NOT_READY_STATUS = "Veuillez d'abord exécuter l'étape de préparation!"
    OBS_START_STATUS = "Observation en cours ..."
    OBS_PLOT_STATUS = "Tracé du graphique ..."
    OBS_DONE_STATUS = "Observation terminée!"

    OBSERVE_TITLE = "Observation du ciel en cours"
    OBSERVE_L1 = "Cela devrait prendre environ 30 secondes ..."
    OBSERVE_L2 = "Un graphique interactif apparaîtra à la fin!"

    FIGURE_TITLE = "Signal de la ligne d'hydrogène (HI) de la Voie Lactée"
    AXIS_FREQ = "Fréquence [MHz]"
    AXIS_INTENSITY = "Intensité [u.a.]"
    ERROR_PREFIX = "Erreur"


class German(StrEnum):
    STATUS = "Status"
    READY = "Bereit"
    PREPARE = "Vorbereiten"
    OBSERVE = "Beobachten"
    EXIT = "Beenden"

    WELCOME_TITLE = "SKAO Tisch-Radioteleskop (TRT) App"
    WELCOME_L1 = "Kurze Bedienungsanleitung:"
    WELCOME_L2 = "1. Vorbereiten"
    WELCOME_L3 = "2. Gewünschte Anzahl an Beobachtungen durchführen"

    ERROR_TITLE = "Etwas ist schiefgelaufen"
    ERROR_L1 = "Weitere Informationen finden Sie in der Statusleiste und am Terminal."
    ERROR_RF = "Nicht genug HF-Leistung. Antenne und LNA-Verbindung prüfen."
    ERROR_NO_DEVICE = "Kein RTL-SDR-Gerät gefunden"
    ERROR_DEVICE_MSG = "Kein RTL-SDR-Gerät erkannt. USB-Verbindung prüfen."
    CHECK_DEVICE = "Prüfen: 1) USB-Kabel angeschlossen  2) librtlsdr installiert  3) Gerät nicht von anderer App genutzt"

    PREP_START_STATUS = "Vorbereitung läuft ..."
    PREP_GAIN_STATUS = "Verstärkung wird getestet"
    PREP_BASELINE_STATUS = "Grundleistungsspektrum wird aufgezeichnet ..."
    PREP_DONE_STATUS = "Vorbereitung abgeschlossen!"

    PREP_STEP1_TITLE = "Vorbereitung läuft"
    PREP_STEP1_L1 = "In diesem Schritt wird Ihr RF-Gerät kalibriert"
    PREP_STEP1_L2 = "Optimaler Verstärkungswert wird gesucht …"

    PREP_STEP2_TITLE = "Vorbereitung läuft"
    PREP_STEP2_L1 = "In diesem Schritt wird Ihr RF-Gerät kalibriert"
    PREP_STEP2_L2 = "Optimaler Verstärkungswert wird gesucht ... FERTIG."
    PREP_STEP2_L3 = "Grundleistungsspektrum wird aufgezeichnet ..."

    PREP_COMPLETE_TITLE = "Vorbereitung abgeschlossen"
    PREP_COMPLETE_L1 = "Optimale Verstärkung"
    PREP_COMPLETE_L2 = "Sie können die Milchstraße beobachten!"
    PREP_COMPLETE_L3 = " - RF-Abschluss entfernen"
    PREP_COMPLETE_L4 = " - Antenne an den Sawbird HI anschließen"
    PREP_COMPLETE_L5 = " - Auf “Beobachten” drücken"

    OBS_NOT_READY_STATUS = "Bitte führen Sie zuerst den Schritt “Vorbereitung” aus!"
    OBS_START_STATUS = "Beobachtung läuft ..."
    OBS_PLOT_STATUS = "Diagramm wird erstellt ..."
    OBS_DONE_STATUS = "Beobachtung abgeschlossen!"

    OBSERVE_TITLE = "Himmelsbeobachtung läuft"
    OBSERVE_L1 = "Dies dauert etwa 30 Sekunden ..."
    OBSERVE_L2 = "Am Ende erscheint ein interaktives Diagramm!"

    FIGURE_TITLE = "Wasserstofflinien-Emission (HI) der Milchstraße"
    AXIS_FREQ = "Frequenz [MHz]"
    AXIS_INTENSITY = "Intensität [w.E.]"
    ERROR_PREFIX = "Fehler"


class Hindi(StrEnum):
    STATUS = "स्थिति"
    READY = "तैयार"
    PREPARE = "तैयारी करें"
    OBSERVE = "अवलोकन करें"
    EXIT = "बाहर निकलें"

    WELCOME_TITLE = "SKAO टेबल-टॉप रेडियो टेलीस्कोप ऐप"
    WELCOME_L1 = "संक्षिप्त निर्देश मैनुअल:"
    WELCOME_L2 = "1. तैयारी करें"
    WELCOME_L3 = "2. जितनी बार चाहें अवलोकन करें"

    ERROR_TITLE = "कुछ गलत हुआ"
    ERROR_L1 = "अधिक जानकारी के लिए स्थिति पट्टी और टर्मिनल जांचें।"
    ERROR_RF = "पर्याप्त RF शक्ति नहीं। एंटीना और LNA कनेक्शन जांचें।"
    ERROR_NO_DEVICE = "कोई RTL-SDR डिवाइस नहीं मिला"
    ERROR_DEVICE_MSG = "कोई RTL-SDR डिवाइस नहीं मिला। USB कनेक्शन जांचें।"
    CHECK_DEVICE = "जांचें: 1) USB केबल लगा है  2) librtlsdr स्थापित है  3) कोई अन्य ऐप डिवाइस उपयोग नहीं कर रहा"

    PREP_START_STATUS = "तैयारी हो रही है ..."
    PREP_GAIN_STATUS = "गेन का प्रयास कर रहे हैं"
    PREP_BASELINE_STATUS = "बेसलाइन पावर स्पेक्ट्रम रिकॉर्ड किया जा रहा है ..."
    PREP_DONE_STATUS = "तैयारी पूर्ण!"

    PREP_STEP1_TITLE = "तैयारी प्रगति पर है"
    PREP_STEP1_L1 = "यह चरण आपके RF डिवाइस को कैलिब्रेट करता है"
    PREP_STEP1_L2 = "इष्टतम गेन खोज रहे हैं ..."

    PREP_STEP2_TITLE = "तैयारी प्रगति पर है"
    PREP_STEP2_L1 = "यह चरण आपके RF डिवाइस को कैलिब्रेट करता है"
    PREP_STEP2_L2 = "इष्टतम गेन खोज रहे हैं ... पूर्ण।"
    PREP_STEP2_L3 = "बेसलाइन पावर स्पेक्ट्रम रिकॉर्ड किया जा रहा है ..."

    PREP_COMPLETE_TITLE = "तैयारी पूर्ण"
    PREP_COMPLETE_L1 = "इष्टतम गेन"
    PREP_COMPLETE_L2 = "आप आकाशगंगा का अवलोकन कर सकते हैं!"
    PREP_COMPLETE_L3 = " - RF टर्मिनेशन हटाएं"
    PREP_COMPLETE_L4 = " - अपने एंटीना को Sawbird HI से कनेक्ट करें"
    PREP_COMPLETE_L5 = " - अवलोकन दबाएं"

    OBS_NOT_READY_STATUS = "कृपया पहले तैयारी चरण चलाएं!"
    OBS_START_STATUS = "अवलोकन हो रहा है ..."
    OBS_PLOT_STATUS = "प्लॉट बनाया जा रहा है ..."
    OBS_DONE_STATUS = "अवलोकन पूर्ण!"

    OBSERVE_TITLE = "आकाश अवलोकन प्रगति पर है"
    OBSERVE_L1 = "इसमें लगभग 30 सेकंड लगेंगे ..."
    OBSERVE_L2 = "अंत में एक इंटरैक्टिव ग्राफ़ दिखाई देगा!"

    FIGURE_TITLE = "आकाशगंगा का हाइड्रोजन लाइन (HI) सिग्नल"
    AXIS_FREQ = "आवृत्ति [MHz]"
    AXIS_INTENSITY = "तीव्रता [इकाई]"
    ERROR_PREFIX = "त्रुटि"


class Italian(StrEnum):
    STATUS = "Stato"
    READY = "Pronto"
    PREPARE = "Preparare"
    OBSERVE = "Osservare"
    EXIT = "Uscire"

    WELCOME_TITLE = "Applicazione per il Radiotelescopio da Tavolo (RTT) di SKAO"
    WELCOME_L1 = "Breve manuale d’istruzione:"
    WELCOME_L2 = "1. Preparati"
    WELCOME_L3 = "2. Osserva quante volte vuoi"

    ERROR_TITLE = "Qualcosa è andato storto!"
    ERROR_L1 = "Controlla la barra di stato e il terminale per maggiori informazioni."
    ERROR_RF = "Potenza RF insufficiente. Controllare antenna e LNA."
    ERROR_NO_DEVICE = "Nessun dispositivo RTL-SDR trovato"
    ERROR_DEVICE_MSG = "Nessun dispositivo RTL-SDR rilevato. Controlla la connessione USB."
    CHECK_DEVICE = "Verificare: 1) Cavo USB collegato  2) librtlsdr installato  3) Nessuna altra app usa il dispositivo"

    PREP_START_STATUS = "Preparazione …"
    PREP_GAIN_STATUS = "Prova del guadagno elettrico in corso"
    PREP_BASELINE_STATUS = (
        "Registrazione dello spettro elettromagnetico di riferimento ..."
    )
    PREP_DONE_STATUS = "Preparazione completata!"

    PREP_STEP1_TITLE = "Preparazione in corso"
    PREP_STEP1_L1 = "Questo passaggio calibra il tuo modulo RF"
    PREP_STEP1_L2 = "Ricerca del guadagno elettrico ottimale ..."

    PREP_STEP2_TITLE = "Preparazione in corso"
    PREP_STEP2_L1 = "Questo passaggio calibra il tuo modulo RF"
    PREP_STEP2_L2 = "Ricerca del guadagno elettrico ottimale ... FATTO."
    PREP_STEP2_L3 = "Registrazione dello spettro elettromagnetico di riferimento ..."

    PREP_COMPLETE_TITLE = "Preparazione completata"
    PREP_COMPLETE_L1 = "Guadagno elettrico ottimale"
    PREP_COMPLETE_L2 = "Puoi osservare la Via Lattea!"
    PREP_COMPLETE_L3 = " - Rimuovi il terminale RF"
    PREP_COMPLETE_L4 = " - Collega l'antenna al Sawbird HI"
    PREP_COMPLETE_L5 = " - Premi osservare"

    OBS_NOT_READY_STATUS = "Esegui prima il passaggio di preparazione!"
    OBS_START_STATUS = "Osservazione in corso ..."
    OBS_PLOT_STATUS = "Tracciamento in corso ..."
    OBS_DONE_STATUS = "Osservazione completata!"

    OBSERVE_TITLE = "Osservazione del cielo in corso"
    OBSERVE_L1 = "Questo dovrebbe richiedere circa 30 secondi ..."
    OBSERVE_L2 = "Alla fine apparirà un grafico interattivo!"

    FIGURE_TITLE = "Segnale della linea dell'idrogeno (HI) della Via Lattea"
    AXIS_FREQ = "Frequenza [MHz]"
    AXIS_INTENSITY = "Intensità [u.a.]"
    ERROR_PREFIX = "Errore"


class Korean(StrEnum):
    STATUS = "상태"
    READY = "대기"
    PREPARE = "준비"
    OBSERVE = "관측"
    EXIT = "종료"

    WELCOME_TITLE = "SKAO 탁상형 전파망원경 (Table-top Radio Telescope) 프로그램"
    WELCOME_L1 = "관측 방법:"
    WELCOME_L2 = "1. 준비"
    WELCOME_L3 = "2. 관측 (필요한 만큼 반복하세요.)"

    ERROR_TITLE = "오류가 발생했습니다."
    ERROR_L1 = "자세한 내용은 상태창과 터미널을 확인하세요."
    ERROR_RF = "RF 전력이 부족합니다. 안테나 및 LNA 연결을 확인하세요."
    ERROR_NO_DEVICE = "RTL-SDR 장치를 찾을 수 없음"
    ERROR_DEVICE_MSG = "RTL-SDR 장치가 감지되지 않았습니다. USB 연결을 확인하세요."
    CHECK_DEVICE = "확인: 1) USB 케이블 연결됨  2) librtlsdr 설치됨  3) 다른 앱이 장치를 사용하지 않음"

    PREP_START_STATUS = "준비 ..."
    PREP_GAIN_STATUS = "재측정"
    PREP_BASELINE_STATUS = "기저선(baseline) 파워 스펙트럼 기록 중 ..."
    PREP_DONE_STATUS = "준비 완료!"

    PREP_STEP1_TITLE = "준비 중입니다"
    PREP_STEP1_L1 = "RF 장비 보정 단계"
    PREP_STEP1_L2 = "적절한 이득값(gain)을 측정 중 ..."

    PREP_STEP2_TITLE = "준비 중입니다"
    PREP_STEP2_L1 = "RF 장비 보정 단계"
    PREP_STEP2_L2 = "적절한 이득값(gain)을 측정 중 ... 완료."
    PREP_STEP2_L3 = "기저선(baseline) 파워 스펙트럼 기록 중 ..."

    PREP_COMPLETE_TITLE = "준비 완료"
    PREP_COMPLETE_L1 = "최적 이득값(gain)"
    PREP_COMPLETE_L2 = "우리은하를 관측할 수 있습니다!"
    PREP_COMPLETE_L3 = " - RF 종단을 분리하세요."
    PREP_COMPLETE_L4 = " - Sawbird HI에 안테나를 연결하세요."
    PREP_COMPLETE_L5 = " - 관측 버튼을 누르세요."

    OBS_NOT_READY_STATUS = "준비 단계를 먼저 실행하세요!"
    OBS_START_STATUS = "관측 중 ..."
    OBS_PLOT_STATUS = "관측 결과 작성 중 ..."
    OBS_DONE_STATUS = "관측 완료!"

    OBSERVE_TITLE = "관측 중입니다"
    OBSERVE_L1 = "30초 동안 관측이 진행됩니다 ..."
    OBSERVE_L2 = "관측이 완료되면 대화형 그래프가 표시됩니다!"

    FIGURE_TITLE = "우리은하의 중성수소선(HI) 신호"
    AXIS_FREQ = "주파수 [MHz]"
    AXIS_INTENSITY = "강도 [임의 단위]"
    ERROR_PREFIX = "오류"


class Japanese(StrEnum):
    STATUS = "ステイタス"
    READY = "準備完了"
    PREPARE = "観測準備"
    OBSERVE = "観測"
    EXIT = "終了"

    WELCOME_TITLE = "SKAO 卓上電波望遠鏡アプリ"
    WELCOME_L1 = "観測ソフトの使い方:"
    WELCOME_L2 = "1. 「観測準備」をクリック"
    WELCOME_L3 = "2. 「観測」をクリック"

    ERROR_TITLE = "観測準備に失敗しました"
    ERROR_L1 = "装置の電源やケーブル接続を確認してください。"
    ERROR_RF = "RF電力が不足しています。アンテナとLNAの接続を確認してください。"
    ERROR_NO_DEVICE = "RTL-SDRデバイスが見つかりません"
    ERROR_DEVICE_MSG = "RTL-SDRデバイスが検出されません。USB接続を確認してください。"
    CHECK_DEVICE = "確認: 1) USBケーブル接続済み  2) librtlsdrインストール済み  3) 他のアプリがデバイスを使用していない"

    PREP_START_STATUS = "観測準備中 ..."
    PREP_GAIN_STATUS = "ゲイン調整中"
    PREP_BASELINE_STATUS = "校正データ取得中 ..."
    PREP_DONE_STATUS = "観測準備が完了しました!"

    PREP_STEP1_TITLE = "観測準備が進行中です"
    PREP_STEP1_L1 = "装置の校正をしています"
    PREP_STEP1_L2 = "ゲインの最適化中です ..."

    PREP_STEP2_TITLE = "装置の校正が継続中です"
    PREP_STEP2_L1 = "ゲインの最適化が完了しました."
    PREP_STEP2_L2 = "校正データを取得しています..."
    PREP_STEP2_L3 = ""

    PREP_COMPLETE_TITLE = "観測準備完了"
    PREP_COMPLETE_L1 = "最適ゲイン値"
    PREP_COMPLETE_L2 = "天の川銀河の観測の準備が整いました!"
    PREP_COMPLETE_L3 = "電波終端を装置から外し、"
    PREP_COMPLETE_L4 = "アンテナをケーブルで装置に繋いでから、"
    PREP_COMPLETE_L5 = "「観測」をクリックしてください"

    OBS_NOT_READY_STATUS = "最初に「観測準備」を実行してください。"
    OBS_START_STATUS = "観測中 ..."
    OBS_PLOT_STATUS = "グラフ表示処理 ..."
    OBS_DONE_STATUS = "観測終了!"

    OBSERVE_TITLE = "観測中"
    OBSERVE_L1 = "30秒ほどお待ちください ..."
    OBSERVE_L2 = "観測終了後に結果のグラフが表示されます"

    FIGURE_TITLE = "天の川銀河の中性水素原子からの21cm輝線"
    AXIS_FREQ = "周波数 [MHz]"
    AXIS_INTENSITY = "強度 [任意単位]"
    ERROR_PREFIX = "エラー"


class Portuguese(StrEnum):
    STATUS = "Status"
    READY = "Pronto"
    PREPARE = "Preparar"
    OBSERVE = "Observar"
    EXIT = "Sair"

    WELCOME_TITLE = "Aplicativo do Telescópio de Rádio de Mesa do SKAO"
    WELCOME_L1 = "Manual de instruções rápido:"
    WELCOME_L2 = "1. Preparar"
    WELCOME_L3 = "2. Observar quantas vezes quiser"

    ERROR_TITLE = "Algo deu errado"
    ERROR_L1 = "Verifique a barra de status e o terminal para mais informações."
    ERROR_RF = "Potência RF insuficiente. Verifique a antena e o LNA."
    ERROR_NO_DEVICE = "Nenhum dispositivo RTL-SDR encontrado"
    ERROR_DEVICE_MSG = "Nenhum dispositivo RTL-SDR detectado. Verifique a ligação USB."
    CHECK_DEVICE = "Verificar: 1) Cabo USB ligado  2) librtlsdr instalado  3) Nenhuma outra app usa o dispositivo"

    PREP_START_STATUS = "Preparando ..."
    PREP_GAIN_STATUS = "Testando ganho"
    PREP_BASELINE_STATUS = "Registando espectro de potência da referência ..."
    PREP_DONE_STATUS = "Preparação concluída!"

    PREP_STEP1_TITLE = "Preparação em andamento"
    PREP_STEP1_L1 = "Esta etapa calibra o seu dispositivo RF"
    PREP_STEP1_L2 = "Procurando o ganho ideal ..."

    PREP_STEP2_TITLE = "Preparação em andamento"
    PREP_STEP2_L1 = "Esta etapa calibra o seu dispositivo RF"
    PREP_STEP2_L2 = "Procurando o ganho ideal ... CONCLUÍDO."
    PREP_STEP2_L3 = "Registando espectro de potência da referência ..."

    PREP_COMPLETE_TITLE = "Preparação concluída"
    PREP_COMPLETE_L1 = "Ganho ideal"
    PREP_COMPLETE_L2 = "Você pode observar a Via Láctea!"
    PREP_COMPLETE_L3 = " - Remova a terminação RF"
    PREP_COMPLETE_L4 = " - Conecte a sua antena ao Sawbird HI"
    PREP_COMPLETE_L5 = " - Pressione Observar"

    OBS_NOT_READY_STATUS = "Por favor, execute a etapa de preparação primeiro!"
    OBS_START_STATUS = "Observando ..."
    OBS_PLOT_STATUS = "Criando gráfico ..."
    OBS_DONE_STATUS = "Observação concluída!"

    OBSERVE_TITLE = "Observação do céu em andamento"
    OBSERVE_L1 = "Isso deve demorar cerca de 30 segundos ..."
    OBSERVE_L2 = "Um gráfico interativo aparecerá no final!"

    FIGURE_TITLE = "Sinal da linha de hidrogênio (HI) da Via Láctea"
    AXIS_FREQ = "Frequência [MHz]"
    AXIS_INTENSITY = "Intensidade [u.a.]"
    ERROR_PREFIX = "Erro"


class Spanish(StrEnum):
    STATUS = "Estado"
    READY = "Listo"
    PREPARE = "Preparar"
    OBSERVE = "Observar"
    EXIT = "Salir"

    WELCOME_TITLE = "Aplicación del Radiotelescopio de Mesa del SKAO"
    WELCOME_L1 = "Manual de instrucciones:"
    WELCOME_L2 = "1. Preparar"
    WELCOME_L3 = "2. Observar tantas veces como desees"

    ERROR_TITLE = "Algo salió mal"
    ERROR_L1 = "Consulta la barra de estado y la terminal para más información."
    ERROR_RF = "Potencia RF insuficiente. Comprueba la antena y el LNA."
    ERROR_NO_DEVICE = "No se encontró dispositivo RTL-SDR"
    ERROR_DEVICE_MSG = "No se detectó ningún dispositivo RTL-SDR. Comprueba la conexión USB."
    CHECK_DEVICE = "Comprobar: 1) Cable USB conectado  2) librtlsdr instalado  3) Ninguna otra app usa el dispositivo"

    PREP_START_STATUS = "Preparando ..."
    PREP_GAIN_STATUS = "Probando ganancia"
    PREP_BASELINE_STATUS = "Registrando el espectro de potencia de referencia ..."
    PREP_DONE_STATUS = "¡Preparación completada!"

    PREP_STEP1_TITLE = "Preparación en progreso"
    PREP_STEP1_L1 = "Este paso calibra tu dispositivo de RF"
    PREP_STEP1_L2 = "Buscando la ganancia óptima ..."

    PREP_STEP2_TITLE = "Preparación en progreso"
    PREP_STEP2_L1 = "Este paso calibra tu dispositivo de RF"
    PREP_STEP2_L2 = "Buscando la ganancia óptima ... HECHO."
    PREP_STEP2_L3 = "Registrando el espectro de potencia de referencia ..."

    PREP_COMPLETE_TITLE = "Preparación completada"
    PREP_COMPLETE_L1 = "Ganancia óptima"
    PREP_COMPLETE_L2 = "¡Puedes observar la Vía Láctea!"
    PREP_COMPLETE_L3 = " - Retira el terminador de RF"
    PREP_COMPLETE_L4 = " - Conecta tu antena al amplificador de bajo ruido"
    PREP_COMPLETE_L5 = " - Pulsa Observar"

    OBS_NOT_READY_STATUS = "¡Por favor, ejecuta primero el paso de preparación!"
    OBS_START_STATUS = "Observando ..."
    OBS_PLOT_STATUS = "Generando gráfica ..."
    OBS_DONE_STATUS = "¡Observación finalizada!"

    OBSERVE_TITLE = "Observación del cielo en progreso"
    OBSERVE_L1 = "Esto debería tardar unos 30 segundos ..."
    OBSERVE_L2 = "¡Una gráfica interactiva aparecerá al final!"

    FIGURE_TITLE = "Señal de la línea de hidrógeno (HI) de la Vía Láctea"
    AXIS_FREQ = "Frecuencia [MHz]"
    AXIS_INTENSITY = "Intensidad [u.a.]"
    ERROR_PREFIX = "Error"



class Ukrainian(StrEnum):
    STATUS = "Статус"
    READY = "Готово"
    PREPARE = "Підготовка"
    OBSERVE = "Спостереження"
    EXIT = "Вихід"

    WELCOME_TITLE = "SpaceRadio — космічне радіо для України"
    WELCOME_L1 = "Короткий посібник користувача:"
    WELCOME_L2 = "1. Підготовка"
    WELCOME_L3 = "2. Спостерігайте стільки разів, скільки бажаєте"

    ERROR_TITLE = "Щось пішло не так"
    ERROR_L1 = "Перевірте рядок стану та термінал для отримання додаткової інформації."
    ERROR_RF = "Недостатньо ВЧ-потужності. Перевірте антену та підсилювач."
    ERROR_NO_DEVICE = "RTL-SDR не знайдено"
    ERROR_DEVICE_MSG = "RTL-SDR донгл не виявлено. Перевірте USB-підключення."
    CHECK_DEVICE = "Перевірте: 1) USB кабель підключено  2) librtlsdr встановлено  3) Інший застосунок не використовує пристрій"

    PREP_START_STATUS = "Підготовка ..."
    PREP_GAIN_STATUS = "Перевірка підсилення"
    PREP_BASELINE_STATUS = "Запис базового спектра потужності ..."
    PREP_DONE_STATUS = "Підготовку завершено!"

    PREP_STEP1_TITLE = "Підготовка виконується"
    PREP_STEP1_L1 = "Цей крок калібрує ваш ВЧ-пристрій"
    PREP_STEP1_L2 = "Пошук оптимального підсилення ..."

    PREP_STEP2_TITLE = "Підготовка виконується"
    PREP_STEP2_L1 = "Цей крок калібрує ваш ВЧ-пристрій"
    PREP_STEP2_L2 = "Пошук оптимального підсилення ... ГОТОВО."
    PREP_STEP2_L3 = "Запис базового спектра потужності ..."

    PREP_COMPLETE_TITLE = "Підготовку завершено"
    PREP_COMPLETE_L1 = "Оптимальне підсилення"
    PREP_COMPLETE_L2 = "Ви можете спостерігати за Чумацьким Шляхом!"
    PREP_COMPLETE_L3 = " - Від'єднайте ВЧ-термінатор"
    PREP_COMPLETE_L4 = " - Підключіть антену до Sawbird HI"
    PREP_COMPLETE_L5 = " - Натисніть «Спостереження»"

    OBS_NOT_READY_STATUS = "Будь ласка, спочатку виконайте крок підготовки!"
    OBS_START_STATUS = "Спостереження ..."
    OBS_PLOT_STATUS = "Побудова графіка ..."
    OBS_DONE_STATUS = "Спостереження завершено!"

    OBSERVE_TITLE = "Спостереження за небом виконується"
    OBSERVE_L1 = "Це займе близько 30 секунд ..."
    OBSERVE_L2 = "Наприкінці з'явиться інтерактивний графік!"

    FIGURE_TITLE = "SpaceRadio — сигнал лінії водню (HI) Чумацького Шляху"
    AXIS_FREQ = "Частота [МГц]"
    AXIS_INTENSITY = "Інтенсивність [в.о.]"
    ERROR_PREFIX = "Помилка"


SUPPORTED_LANGUAGES: Final[dict[str, tuple[English, str]]] = {
    "English": (English, "Arial"),
    "Afrikaans": (Afrikaans, "Arial"),
    "Deutsch": (German, "Arial"),
    "Español": (Spanish, "Arial"),
    "Français": (French, "Arial"),
    "Hindi": (Hindi, "Nirmala UI"),
    "Italiano": (Italian, "Arial"),
    "Nederlands": (Dutch, "Arial"),
    "Português": (Portuguese, "Arial"),
    "Українська": (Ukrainian, "Arial"),
    "简体中文": (Chinese, "SimSun"),
    "한국어": (Korean, "Malgun Gothic"),
    "日本語": (Japanese, "MS Gothic"),
}
