from typing import Any, Callable, Optional

from numpy import ptp
from numpy.typing import NDArray

from skao_trt.gain_search import find_optimal_gain
from skao_trt.record_data import record_power_spectrum
from skao_trt.sdr_wrapper import MockRtlSdr


class ObsManager:
    """
    Manages the recording, storing and plotting the data.
    Does not perform any exception handling, this is deferred to the caller.

    Note: rtlsdr is imported lazily (only when mock_device=False) so that
    mock/demo mode works even when librtlsdr is missing or incompatible.
    """

    def __init__(
        self,
        mock_device: bool = False,
    ) -> None:
        self._mock_device = mock_device
        if mock_device:
            self.sdr_class = MockRtlSdr
        else:
            # Lazy import: only load rtlsdr when real hardware is requested.
            # This allows --mock mode to run without a working librtlsdr.
            try:
                import rtlsdr
                self.sdr_class = rtlsdr.RtlSdr
            except (ImportError, AttributeError) as exc:
                raise RuntimeError(
                    "\n\n"
                    "  Модуль pyrtlsdr не знайдено або несумісна версія librtlsdr.\n"
                    "  Для демо-режиму без обладнання запустіть з прапором --mock:\n"
                    "\n"
                    "    ~/SpaceRadio/launch_spaceradio.sh --mock\n"
                    "\n"
                    f"  Технічна причина: {exc}\n"
                ) from exc

        self.gain: float | None = None
        self.baseline_power_spectrum: tuple[NDArray, NDArray] | None = None

    @property
    def ready_to_record(self) -> bool:
        return self.gain is not None

    @property
    def ready_to_observe(self) -> bool:
        return self.baseline_power_spectrum is not None

    def find_optimal_gain(
        self,
        callback: Optional[Callable[[float], Any]] = None,
    ) -> None:
        self.gain = find_optimal_gain(self.sdr_class, callback=callback)

    def record_baseline_power_spectrum(self) -> None:
        if not self.ready_to_record:
            return
        self.baseline_power_spectrum = record_power_spectrum(self.sdr_class, self.gain)

    def record_normalised_sky_power_spectrum(self) -> tuple[NDArray, NDArray]:
        if not self.ready_to_observe:
            return
        freq, pwr = record_power_spectrum(self.sdr_class, self.gain)
        __, baseline_pwr = self.baseline_power_spectrum
        pwr = pwr / baseline_pwr
        pwr = (pwr - pwr.min()) / ptp(pwr)
        return freq, pwr
