from __future__ import annotations

import argparse
import os
import sys
import tkinter as tk
import tkinter.font
import traceback
from importlib import resources
from pathlib import Path
from typing import Any, Callable, Optional, Union

from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk


class UkrainianToolbar(NavigationToolbar2Tk):
    """NavigationToolbar2Tk with Ukrainian tooltips and button labels."""
    toolitems = [
        (t[0], t[1], t[2], t[3]) if t[0] is None else (
            {
                'Home':    'Початок',
                'Back':    'Назад',
                'Forward': 'Вперед',
                'Pan':     'Переміщення',
                'Zoom':    'Масштаб',
                'Subplots': 'Підграфіки',
                'Save':    'Зберегти',
            }.get(t[0], t[0]),
            {
                'Home':     'Повернутись до початкового вигляду',
                'Back':     'Попередній вигляд',
                'Forward':  'Наступний вигляд',
                'Pan':      'Ліва кнопка — переміщення, права — масштаб',
                'Zoom':     'Масштабувати до прямокутника',
                'Subplots': 'Налаштування підграфіків',
                'Save':     'Зберегти зображення',
            }.get(t[1], t[1]),
            t[2], t[3],
        )
        for t in NavigationToolbar2Tk.toolitems
    ]
from matplotlib.figure import Figure
from numpy.typing import NDArray
from PIL import Image, ImageTk

from skao_trt.apps.languages import SUPPORTED_LANGUAGES
from skao_trt.apps.obs_manager import ObsManager
from skao_trt.gain_search import NotEnoughRFPower


class DeviceNotFoundError(Exception):
    """Raised when no RTL-SDR USB device can be opened."""
    pass


def check_sdr_device() -> None:
    """
    Try to open the RTL-SDR device. Raises DeviceNotFoundError with a
    diagnostic message if the device cannot be found or opened.

    On macOS the most common causes are:
      1. Dongle not plugged in
      2. librtlsdr not installed / wrong version (missing rtlsdr_set_dithering)
      3. Another application (e.g. GQRX, SDR#) already has the device open
      4. macOS USB permissions / SIP blocking the driver
    """
    try:
        import rtlsdr
        sdr = rtlsdr.RtlSdr()
        sdr.close()
    except Exception as exc:
        msg = str(exc)
        # Classify the error for a cleaner message
        if 'rtlsdr_set_dithering' in msg or 'symbol not found' in msg:
            raise DeviceNotFoundError(
                "librtlsdr_DRIVER_OLD"
            ) from exc
        elif 'No RTL-SDR' in msg or 'no device' in msg.lower() or 'usb' in msg.lower():
            raise DeviceNotFoundError(
                "librtlsdr_NO_DEVICE"
            ) from exc
        else:
            raise DeviceNotFoundError(
                f"librtlsdr_OTHER:{msg}"
            ) from exc

# Ukrainian flag colours replace SKAO brand colours
SKAO_BLUE    = "#005BBB"   # Ukrainian blue
SKAO_MAGENTA = "#FFD700"   # Ukrainian gold
from skao_trt.plotting import plot_power_spectrum_on_axes

ConfigDict = dict[str, Any]


def make_config(width_pixels: int) -> ConfigDict:
    dpi = width_pixels / 1000 * 80
    return {
        "window.width": width_pixels,
        "window.fontsize": 10,
        "figure.aspect_ratio": 0.5,
        "figure.dpi": dpi,
        "figure.text.fontsize": 28,
        "figure.axislabels.fontsize": 14,
        "figure.ticklabels.fontsize": 12,
        "figure.title.fontsize": 18,
        "figure.text.x": 0.12,
        "figure.text.y": 0.70,
        "figure.text.dy": 0.1,
    }




def get_default_font_family() -> str:
    font = tkinter.font.nametofont("TkCaptionFont")
    return font.actual()["family"]


def get_logo_path() -> Path:
    return Path(str(resources.files("skao_trt") / "img" / "skao_logo_bar.jpg"))


class LogoBar:
    """
    Wrapper for the Label containing the SKAO logo.
    """
    def __init__(self, parent: tk.Widget, imgpath: PathLike, *, width: int) -> None:
        image = Image.open(imgpath)
        aspect_ratio = image.width / image.height
        height = round(width / aspect_ratio)
        image = image.resize((width, height))
        image = ImageTk.PhotoImage(image)
        self.label = tk.Label(parent, image=image)
        self.label.image = image

    def dispose(self) -> None:
        self.label.pack(side=tk.TOP, fill=tk.BOTH)


class InteractiveFigure:
    """
    Wrapper for the matplotlib Figure containing the power spectrum plot.
    """

    def __init__(
        self, parent: tk.Widget, config: ConfigDict, title: str, font: str,
        xlabel: str = "Frequency [MHz]", ylabel: str = "Intensity [a.u.]",
    ) -> None:
        # Frame containing both the figure and the toolbar
        self.config = config
        self.title = title
        self.font = font
        self.xlabel = xlabel
        self.ylabel = ylabel

        width = config["window.width"]
        self.frame = tk.Frame(parent, width=width)

        height = round(config["figure.aspect_ratio"] * width)
        dpi = config["figure.dpi"]
        self.fig = Figure(figsize=(width / dpi, height / dpi), dpi=dpi)
        self.ax = self.fig.add_subplot(111)
        # Make sure the figure occupies the whole frame
        self.fig.subplots_adjust(left=0.07, right=0.97, bottom=0.1, top=0.95)
        self.canvas = FigureCanvasTkAgg(self.fig, master=self.frame)
        self.clear_axes()
        self.navbar = UkrainianToolbar(self.canvas, window=self.frame)

    def clear_axes(self) -> None:
        self.ax.clear()
        self.ax.axis("off")
        self.canvas.draw()

    def display_text(self, title: str, lines: list[str]):
        """
        Display given lines of text on the plotting area. Title is shown at
        the top, in bold and in a different color.
        """
        self.clear_axes()

        fontsize = self.config["figure.text.fontsize"]
        x = self.config["figure.text.x"]
        y = self.config["figure.text.y"]
        ystep = self.config["figure.text.dy"]

        self.ax.text(
            x,
            y,
            title,
            fontsize=fontsize,
            fontweight="bold",
            color=SKAO_MAGENTA,
            font=self.font,
        )
        y -= ystep

        for line in lines:
            self.ax.text(x, y, line, fontsize=fontsize, color=SKAO_BLUE, font=self.font)
            y -= ystep

        self.canvas.draw()

    def dispose(self) -> None:
        self.frame.pack(side=tk.TOP, fill=tk.BOTH, expand=True)
        self.canvas.get_tk_widget().pack(side=tk.TOP, fill=tk.BOTH, expand=True)
        self.navbar.pack(side=tk.BOTTOM, fill=tk.X, expand=True)

    def plot_power_spectrum(self, freq: NDArray, pwr: NDArray) -> None:
        self.clear_axes()
        plot_power_spectrum_on_axes(self.ax, freq, pwr, xlabel=self.xlabel, ylabel=self.ylabel)
        self.ax.set_xlabel(
            self.ax.get_xlabel(), fontsize=self.config["figure.axislabels.fontsize"]
        )
        self.ax.set_ylabel(
            self.ax.get_ylabel(), fontsize=self.config["figure.axislabels.fontsize"]
        )
        self.ax.set_ylim(0.0, 1.01 * pwr.max())
        self.ax.tick_params(
            axis="both",
            which="major",
            labelsize=self.config["figure.ticklabels.fontsize"],
        )
        self.ax.axis("on")  # don't forget to turn axes back on
        self.ax.set_title(
            self.title, fontsize=self.config["figure.title.fontsize"], font=self.font
        )
        self.canvas.draw()


class ButtonsBar:
    """
    Wrapper for a Frame containing buttons laid out horizontally.
    """

    def __init__(
        self,
        parent: tk.Widget,
        button_definitions: list[tuple[str, Callable]],
        *,
        font: tuple[str, int],
    ) -> None:
        self.frame = tk.Frame(parent)
        self.buttons: list[tk.Button] = []
        self.font = font
        for text, command in button_definitions:
            self._create_button(text, command=command)

    def _create_button(
        self, text: str, command: Optional[Callable] = None
    ) -> tk.Button:
        button = tk.Button(self.frame, text=text, command=command, font=self.font)
        self.buttons.append(button)

    def dispose(self) -> None:
        for col in range(len(self.buttons)):
            self.frame.grid_columnconfigure(col, weight=1)
        for i, button in enumerate(self.buttons):
            button.grid(column=i, row=0, sticky="ew")
        self.frame.pack(side=tk.BOTTOM, fill=tk.X)


class StatusBar:
    """
    Wrapper for the status bar Label.
    """

    def __init__(
        self, parent: tk.Widget, font: tuple[str, int], status: str, ready: str
    ) -> None:
        self.label = tk.Label(
            parent,
            font=font,
            relief=tk.SUNKEN,
            anchor=tk.W,
            height=2,
        )
        self.status = status
        self.update_status(ready)

    def dispose(self) -> None:
        self.label.pack(side=tk.BOTTOM, fill=tk.X)

    def update_status(self, message: str) -> None:
        self.label.config(text=f"{self.status}: " + message)


class TabletopApp:
    """
    Main application class.
    """

    def __init__(
        self,
        width_pixels: int = 1200,
        *,
        mock_device: bool = False,
        language: str = "Українська",
    ) -> None:
        self.lines = SUPPORTED_LANGUAGES[language][0]
        self.font = SUPPORTED_LANGUAGES[language][1]

        self.root = tk.Tk()
        self.root.title(self.lines.WELCOME_TITLE)
        self.config = make_config(width_pixels)

        self.logo_bar = None
        self.interactive_figure = None
        self.buttons_bar = None
        self.status_bar = None

        self.obs_manager = ObsManager(mock_device)
        self._create_widgets()
        self._dispose_widgets()
        self._display_welcome_text()

    def _create_widgets(self) -> None:
        font = (get_default_font_family(), self.config["window.fontsize"])
        config = self.config
        self.logo_bar = LogoBar(
            self.root, get_logo_path(), width=config["window.width"]
        )
        self.interactive_figure = InteractiveFigure(
            self.root, self.config, self.lines.FIGURE_TITLE, font=self.font,
            xlabel=self.lines.AXIS_FREQ, ylabel=self.lines.AXIS_INTENSITY,
        )
        button_definitions = [
            (self.lines.PREPARE, self.prepare),
            (self.lines.OBSERVE, self.observe),
            (self.lines.EXIT, self.exit),
        ]
        self.buttons_bar = ButtonsBar(self.root, button_definitions, font=font)
        self.status_bar = StatusBar(
            self.root, font, self.lines.STATUS, self.lines.READY
        )

    def _dispose_widgets(self) -> None:
        """
        Dispose the widgets in the main window once they are created.
        """
        self.logo_bar.dispose()
        # NOTE: dispose the widgets fom bottom to top
        self.status_bar.dispose()
        self.buttons_bar.dispose()
        self.interactive_figure.dispose()
        self.root.resizable(False, False)

    def _display_welcome_text(self) -> None:
        self.interactive_figure.display_text(
            self.lines.WELCOME_TITLE,
            [
                self.lines.WELCOME_L1,
                self.lines.WELCOME_L2,
                self.lines.WELCOME_L3,
            ],
        )

    def update_status(self, message: str) -> None:
        self.status_bar.update_status(message)
        # Force full UI refresh so status + plot text update immediately
        self.root.update()

    def display_error(self, err: Exception) -> None:
        from skao_trt.gain_search import NotEnoughRFPower

        self.interactive_figure.display_text(
            self.lines.ERROR_TITLE,
            [
                self.lines.ERROR_L1,
            ],
        )
        print(traceback.format_exc())
        if isinstance(err, NotEnoughRFPower):
            self.update_status(f"{self.lines.ERROR_PREFIX}: {self.lines.ERROR_RF}")
        else:
            self.update_status(f"{self.lines.ERROR_PREFIX}: {err!s}")

    def prepare(self) -> None:
        self.update_status(self.lines.PREP_START_STATUS)

        # ── Device check (skip for mock mode) ───────────────────────────── #
        if not self.obs_manager._mock_device:
            try:
                check_sdr_device()
            except DeviceNotFoundError as exc:
                code = str(exc)
                if 'DRIVER_OLD' in code:
                    detail = (
                        "librtlsdr стара версія (відсутній rtlsdr_set_dithering).\n"
                        "Запустіть: brew uninstall rtl-sdr && "
                        "git clone https://github.com/librtlsdr/librtlsdr && "
                        "cmake+make install"
                    )
                elif 'NO_DEVICE' in code:
                    detail = self.lines.CHECK_DEVICE
                else:
                    detail = code.replace('librtlsdr_OTHER:', '')
                self.interactive_figure.display_text(
                    self.lines.ERROR_NO_DEVICE,
                    [self.lines.ERROR_DEVICE_MSG, detail],
                )
                self.update_status(
                    f"{self.lines.ERROR_PREFIX}: {self.lines.ERROR_NO_DEVICE}"
                )
                return

        self.interactive_figure.display_text(
            self.lines.PREP_STEP1_TITLE,
            [
                self.lines.PREP_STEP1_L1,
                self.lines.PREP_STEP1_L2,
            ],
        )
        # Force UI redraw before blocking gain search starts
        self.root.update()

        # Find optimal gain
        try:
            self.obs_manager.find_optimal_gain(
                callback=lambda gain: self.update_status(
                    f"{self.lines.PREP_GAIN_STATUS} = {gain:.1f}"
                )
            )
        except NotEnoughRFPower as err:
            self.display_error(err)
            return
        except Exception as err:
            self.display_error(err)
            return

        self.interactive_figure.display_text(
            self.lines.PREP_STEP2_TITLE,
            [
                self.lines.PREP_STEP2_L1,
                self.lines.PREP_STEP2_L2,
                self.lines.PREP_STEP2_L3,
            ],
        )
        self.root.update()

        # Record baseline power spectrum
        try:
            self.update_status(self.lines.PREP_BASELINE_STATUS)
            self.obs_manager.record_baseline_power_spectrum()
        except Exception as err:
            self.display_error(err)
            return

        self.update_status(self.lines.PREP_DONE_STATUS)
        optimal_gain = self.obs_manager.gain
        self.interactive_figure.display_text(
            self.lines.PREP_COMPLETE_TITLE,
            [
                f"{self.lines.PREP_COMPLETE_L1} = {optimal_gain:.2f}",
                self.lines.PREP_COMPLETE_L2,
                self.lines.PREP_COMPLETE_L3,
                self.lines.PREP_COMPLETE_L4,
                self.lines.PREP_COMPLETE_L5,
            ],
        )

    def observe(self) -> None:
        if not self.obs_manager.ready_to_observe:
            self.update_status(self.lines.OBS_NOT_READY_STATUS)
            return

        self.interactive_figure.clear_axes()
        self.interactive_figure.display_text(
            self.lines.OBSERVE_TITLE,
            [
                self.lines.OBSERVE_L1,
                self.lines.OBSERVE_L2,
            ],
        )
        self.update_status(self.lines.OBS_START_STATUS)

        try:
            freq, pwr = self.obs_manager.record_normalised_sky_power_spectrum()
        except Exception as err:
            self.display_error(err)
            return

        self.update_status(self.lines.OBS_PLOT_STATUS)
        self.interactive_figure.plot_power_spectrum(freq, pwr)
        self.update_status(self.lines.OBS_DONE_STATUS)

    def exit(self) -> None:
        self.root.destroy()

    def run(self) -> None:
        self.root.mainloop()


def parse_args(*argv):
    parser = argparse.ArgumentParser(
        description="Launch the SKAO Table-top Radio Telescope / SpaceRadio App"
    )
    parser.add_argument(
        "--mock",
        action="store_true",
        help="Use a mock version of the SDR device which generates white noise",
    )
    parser.add_argument(
        "--width",
        type=int,
        default=1200,
        help="Main window width in pixels",
    )
    parser.add_argument(
        "--language",
        type=str,
        choices=SUPPORTED_LANGUAGES.keys(),
        default="Українська",
        help=f"Choose a language to use: {', '.join(SUPPORTED_LANGUAGES.keys())}",
    )
    args, _ = parser.parse_known_args()
    return args


def main(*argv):
    args = parse_args()
    TabletopApp(args.width, mock_device=args.mock, language=args.language).run()


if __name__ == "__main__":
    main(*sys.argv[1:])
