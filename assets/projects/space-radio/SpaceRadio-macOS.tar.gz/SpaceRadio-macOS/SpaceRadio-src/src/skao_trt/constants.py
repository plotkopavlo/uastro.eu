from typing import Final

HI_FREQ_MHZ: Final = 1420.40575
SKAO_BLUE: Final = "#070068"
SKAO_MAGENTA: Final = "#E50869"