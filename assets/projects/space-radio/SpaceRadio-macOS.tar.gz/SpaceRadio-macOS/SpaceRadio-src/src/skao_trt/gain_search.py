from __future__ import annotations

from typing import Any, Callable, Optional, Type

from .sdr_wrapper import Gain, MockRtlSdr


class NotEnoughRFPower(Exception):
    pass


def find_optimal_gain(
    sdr_class: Type,
    sample_rate_hz: float = 2.048e6,
    centre_freq_hz: float = 1420.4e6,
    callback: Optional[Callable[[Gain], Any]] = None,
) -> float:
    """
    Find the optimal gain setting for the SDR device.
    Works with both MockRtlSdr and real rtlsdr.RtlSdr.
    """
    sdr = sdr_class()
    sdr.sample_rate = sample_rate_hz
    sdr.center_freq = centre_freq_hz

    try:
        for gain in sdr.valid_gains_db:
            if callback:
                callback(gain)

            sdr.gain = gain
            dat = sdr.read_samples(int(sample_rate_hz))

            average_stddev = 0.5 * (dat.real.std() + dat.imag.std())
            print(
                f"SDR gain = {sdr.get_gain():.2f}, "
                f"average stddev = {average_stddev:.3f}"
            )
            if average_stddev > 0.25:
                print(f"Found optimal gain: {gain:.2f}")
                return gain

        raise NotEnoughRFPower("Not enough RF Power, check your system!")

    finally:
        sdr.close()
