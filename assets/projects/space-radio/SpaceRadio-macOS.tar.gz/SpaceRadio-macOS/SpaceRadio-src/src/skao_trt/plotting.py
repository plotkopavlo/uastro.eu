import matplotlib.pyplot as plt
from numpy.typing import NDArray
from .constants import SKAO_BLUE, SKAO_MAGENTA, HI_FREQ_MHZ


def plot_power_spectrum(
    freq_hz: NDArray,
    power: NDArray,
    xlabel: str = "Frequency [MHz]",
    ylabel: str = "Intensity [a.u.]",
) -> plt.Figure:
    fig = plt.figure(0, figsize=(10.0, 6))
    ax = fig.add_subplot(1, 1, 1)
    plot_power_spectrum_on_axes(ax, freq_hz, power, xlabel=xlabel, ylabel=ylabel)
    return fig


def plot_power_spectrum_on_axes(
    ax: plt.Axes,
    freq_hz: NDArray,
    power: NDArray,
    xlabel: str = "Frequency [MHz]",
    ylabel: str = "Intensity [a.u.]",
) -> None:
    freq_mhz = freq_hz / 1.0e6
    ax.plot(freq_mhz, power, color=SKAO_BLUE)

    # axvline uses axes coordinates (ymin/ymax 0-1) so it always spans the
    # full plot height regardless of when set_ylim is called.
    ax.axvline(HI_FREQ_MHZ, linestyle="dashed", color=SKAO_MAGENTA)
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    ax.set_xlim(freq_mhz.min(), freq_mhz.max())
    ax.grid("major", linestyle=":")
