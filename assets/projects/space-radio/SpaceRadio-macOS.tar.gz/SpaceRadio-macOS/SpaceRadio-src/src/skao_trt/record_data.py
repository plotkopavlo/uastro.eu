from __future__ import annotations

from typing import Type

import numpy as np
from numpy.typing import NDArray

from .sdr_wrapper import Gain, MockRtlSdr


def record_power_spectrum(
    sdr_class: Type,
    gain: Gain,
    sample_rate_hz: float = 2.048e6,
    centre_freq_hz: float = 1420.4e6,
    num_samples: int = 2**26,
    max_read_size: int = 2**23,
    num_integration_bins: int = 256,
) -> tuple[NDArray, NDArray]:
    """
    Record power spectrum data using a software-defined radio (SDR) device.
    Default values are adjusted to record a small band around the HI line.
    """
    if num_samples % max_read_size:
        raise ValueError("max_read_size must divide num_samples")
    if num_samples % num_integration_bins:
        raise ValueError("num_integration_bins must divide num_samples")

    sdr = sdr_class()
    sdr.sample_rate = sample_rate_hz
    sdr.center_freq = centre_freq_hz
    sdr.gain = gain

    num_reads = num_samples // max_read_size
    total_power = np.zeros(num_integration_bins)

    print(
        f"Recording {num_samples} samples in {num_reads} reads of "
        f"{max_read_size} samples each"
    )

    try:
        for _ in range(num_reads):
            dat = sdr.read_samples(max_read_size)
            signal_spectrum = np.fft.fftshift(np.fft.fft(dat))
            pwr = np.abs(signal_spectrum / len(dat) * 2) ** 2
            pwr_integrated = pwr.reshape(num_integration_bins, -1).sum(axis=1)
            total_power += pwr_integrated

    except Exception:
        # Catch LibUSBError and any other device error; let caller handle it
        raise

    finally:
        sdr.close()

    freq_hz = np.fft.fftfreq(num_integration_bins, d=1.0 / sdr.sample_rate)
    freq_hz = np.fft.fftshift(freq_hz)
    freq_hz = freq_hz + sdr.center_freq
    return freq_hz, total_power
