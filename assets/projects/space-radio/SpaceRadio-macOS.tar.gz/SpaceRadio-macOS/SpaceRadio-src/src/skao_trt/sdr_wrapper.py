from __future__ import annotations

from typing import TYPE_CHECKING, Final, Union

import numpy as np

# rtlsdr is imported lazily at runtime so that mock/demo mode works even when
# librtlsdr is absent or has missing symbols (e.g. rtlsdr_set_dithering on v5).
if TYPE_CHECKING:
    import rtlsdr  # only for type-checker; never executed at runtime

Gain = Union[float, str]


def parse_gain(gain_str: str) -> Gain:
    """
    Parse a string containing a gain value, e.g. "3.14" or "auto".
    """
    if gain_str == "auto":
        return gain_str
    try:
        return float(gain_str)
    except TypeError as err:
        raise TypeError(f"Invalid gain string: {gain_str!r}") from err


class MockRtlSdr:
    """
    Mock version of an rtlsdr.RtlSdr device. Used when no SDR device is
    connected so that the app can run in demo mode. It has the same interface
    as rtlsdr.RtlSdr, except that read_samples() generates Gaussian noise.
    """

    MAX_READ_SAMPLES: Final[int] = 2**24

    GAINS: Final[list[float]] = [
        1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 9.0, 11.0, 14.0, 16.0, 17.0, 19.0,
        21.0, 22.0, 25.0, 27.0, 29.0, 32.0, 34.0, 36.0, 37.0, 38.0, 40.0,
        42.0, 43.0, 44.0, 45.0, 47.0,
    ]

    def __init__(self) -> None:
        self.sample_rate = 2.048e6   # Hz
        self.center_freq = 1420.4e6  # Hz
        self.gain: Gain = 1.0

    def close(self) -> None:
        pass

    def read_samples(self, num_samples: Union[int, float]) -> np.ndarray:
        n = int(num_samples)
        if not n > 0:
            raise ValueError("Number of samples to read must be > 0")
        if n > self.MAX_READ_SAMPLES:
            raise RuntimeError(
                f"Requested {n} samples exceeds MockRtlSdr limit of {self.MAX_READ_SAMPLES}"
            )
        # Fixed scale: stddev stays well below 0.25 threshold at all gains,
        # so find_optimal_gain always exhausts all gains and raises NotEnoughRFPower.
        # This matches the original behaviour with a real (disconnected) device.
        scale = 0.01
        real = np.random.normal(size=n, scale=scale)
        imag = np.random.normal(size=n, scale=scale)
        return real + 1.0j * imag

    def get_gain(self) -> float:
        if self.gain == "auto":
            return 1.0
        return float(self.gain)

    @property
    def valid_gains_db(self) -> list[float]:
        return self.GAINS


# SdrDevice is a runtime type alias used for isinstance checks / annotations.
# We cannot use rtlsdr.RtlSdr here because rtlsdr may not be importable;
# callers that need the real class must import it themselves lazily.
SdrDevice = MockRtlSdr  # type: ignore[assignment]
