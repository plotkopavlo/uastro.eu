#!/bin/bash
# =============================================================================
#  SpaceRadio — RTL-SDR macOS Diagnostic Tool
#  Run this if the dongle is not detected by SpaceRadio
# =============================================================================

BREW_PREFIX=$(brew --prefix 2>/dev/null || echo "/opt/homebrew")

echo ""
echo "  ╔══════════════════════════════════════╗"
echo "  ║  SpaceRadio — RTL-SDR Diagnostics   ║"
echo "  ╚══════════════════════════════════════╝"
echo ""

# 1. Check librtlsdr is present
echo "── 1. librtlsdr library ──────────────────"
DYLIB="${BREW_PREFIX}/lib/librtlsdr.dylib"
if [[ -f "${DYLIB}" ]]; then
    echo "  ✓ Found: ${DYLIB}"
else
    echo "  ✗ NOT FOUND: ${DYLIB}"
    echo "    Fix: cd librtlsdr/build && cmake .. -DCMAKE_INSTALL_PREFIX=${BREW_PREFIX} \\"
    echo "           -DLIBUSB_INCLUDE_DIR=${BREW_PREFIX}/include/libusb-1.0 \\"
    echo "           -DLIBUSB_LIBRARIES=${BREW_PREFIX}/lib/libusb-1.0.dylib \\"
    echo "           -DINSTALL_UDEV_RULES=OFF && make && make install"
fi

# 2. Check rtlsdr_set_dithering (RTL-SDR v5 symbol)
echo ""
echo "── 2. RTL-SDR v5 compatibility ──────────"
python3 -c "
import ctypes, sys
try:
    lib = ctypes.CDLL('${DYLIB}')
    _ = lib.rtlsdr_set_dithering
    print('  ✓ rtlsdr_set_dithering found — v5 compatible')
except OSError:
    print('  ✗ Cannot load librtlsdr.dylib')
except AttributeError:
    print('  ✗ rtlsdr_set_dithering MISSING — library too old')
    print('    Fix: rebuild librtlsdr from https://github.com/librtlsdr/librtlsdr')
" 2>/dev/null || echo "  ✗ Python check failed"

# 3. Check USB device is present
echo ""
echo "── 3. USB device detection ──────────────"
if command -v system_profiler &>/dev/null; then
    RTL=$(system_profiler SPUSBDataType 2>/dev/null | grep -i "RTL\|0bda\|2832\|2838\|2888" | head -5)
    if [[ -n "${RTL}" ]]; then
        echo "  ✓ RTL-SDR USB device found:"
        echo "${RTL}" | sed 's/^/    /'
    else
        echo "  ✗ No RTL-SDR USB device detected"
        echo "    Check: dongle plugged in? Try a different USB port or cable."
    fi
fi

# 4. Check rtl_test CLI tool
echo ""
echo "── 4. rtl_test command ──────────────────"
if command -v rtl_test &>/dev/null; then
    echo "  ✓ rtl_test found: $(which rtl_test)"
    echo "  Running quick test (3 seconds)..."
    DYLD_LIBRARY_PATH="${BREW_PREFIX}/lib" timeout 3 rtl_test -t 2>&1 | head -10 | sed 's/^/    /'
else
    echo "  ✗ rtl_test not found (normal if built from source without PATH update)"
fi

# 5. Check if another process holds the device
echo ""
echo "── 5. Conflicting processes ─────────────"
CONFLICTS=$(lsof 2>/dev/null | grep -i "rtl\|sdr" | grep -v "grep" | head -5)
if [[ -n "${CONFLICTS}" ]]; then
    echo "  ⚠ Possible conflict — these processes may hold the device:"
    echo "${CONFLICTS}" | sed 's/^/    /'
    echo "  Fix: quit GQRX, SDR#, CubicSDR, or any other SDR application first"
else
    echo "  ✓ No obvious conflicting processes"
fi

# 6. pyrtlsdr
echo ""
echo "── 6. pyrtlsdr Python module ────────────"
"${HOME}/SpaceRadio/venv/bin/python" -c "
import rtlsdr
print('  ✓ pyrtlsdr importable')
try:
    sdr = rtlsdr.RtlSdr()
    print('  ✓ RTL-SDR device opened successfully!')
    print(f'    Sample rate: {sdr.sample_rate/1e6:.3f} MHz')
    print(f'    Gains available: {sdr.valid_gains_db[:5]} ...')
    sdr.close()
except Exception as e:
    print(f'  ✗ Cannot open device: {e}')
" 2>/dev/null || echo "  ✗ pyrtlsdr not importable (run install.sh first)"

echo ""
echo "══════════════════════════════════════════"
echo "  If the device is not found, try:"
echo "  1. Unplug and replug the RTL-SDR dongle"
echo "  2. Try a different USB port"
echo "  3. Quit any other SDR applications"
echo "  4. Rebuild librtlsdr (see step 2 above)"
echo "  5. Restart your Mac"
echo "══════════════════════════════════════════"
echo ""
