#!/bin/bash
# =============================================================================
#  SpaceRadio для України — macOS Installer
#  Version: 0.3.1
#  https://gitlab.com/ska-telescope/ska-tabletop-radiotelescope
# =============================================================================
#
#  ЗАПУСК:
#    chmod +x install.sh
#    ./install.sh
#
#  Цей скрипт встановлює SpaceRadio з папки SpaceRadio-src/
#  поруч із ним. Не переміщайте install.sh без SpaceRadio-src/.
# =============================================================================

set -euo pipefail

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; BOLD='\033[1m'; NC='\033[0m'
info()    { echo -e "${CYAN}[INFO]${NC}  $*"; }
success() { echo -e "${GREEN}[OK]${NC}    $*"; }
warn()    { echo -e "${YELLOW}[WARN]${NC}  $*"; }
error()   { echo -e "${RED}[ERROR]${NC} $*" >&2; }
step()    { echo -e "\n${BOLD}==> $*${NC}"; }

INSTALL_DIR="${HOME}/SpaceRadio"
VENV_DIR="${INSTALL_DIR}/venv"
LAUNCHER="${INSTALL_DIR}/launch_spaceradio.sh"
COMMAND_FILE="${INSTALL_DIR}/SpaceRadio.command"
DESKTOP="${HOME}/Desktop"
MIN_PYTHON_MINOR=11

# Знайти папку SpaceRadio-src/ поруч із цим скриптом
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SRC_DIR="${SCRIPT_DIR}/SpaceRadio-src"

echo ""
echo -e "${BOLD}${CYAN}"
echo "  ╔══════════════════════════════════════════════════════════════╗"
echo "  ║          SpaceRadio для України — macOS Installer            ║"
echo "  ║                       Version 0.3.1                         ║"
echo "  ╚══════════════════════════════════════════════════════════════╝"
echo -e "${NC}"

# ── Перевірка вихідного коду ─────────────────────────────────────────────── #
step "Перевірка вихідного коду"
if [[ ! -d "${SRC_DIR}" ]]; then
    error "Папку SpaceRadio-src/ не знайдено поруч із install.sh"
    error "Переконайтесь що архів розпаковано повністю."
    exit 1
fi
if [[ ! -f "${SRC_DIR}/pyproject.toml" ]]; then
    error "SpaceRadio-src/pyproject.toml не знайдено — архів пошкоджений."
    exit 1
fi
success "Вихідний код знайдено: ${SRC_DIR}"

# ── macOS ────────────────────────────────────────────────────────────────── #
step "Перевірка операційної системи"
if [[ "$(uname -s)" != "Darwin" ]]; then
    error "Цей інсталятор лише для macOS. Виявлено: $(uname -s)"
    exit 1
fi
success "macOS $(sw_vers -productVersion) виявлено."

ARCH=$(uname -m)
if [[ "${ARCH}" == "arm64" ]]; then
    info "Apple Silicon (arm64) виявлено."
    BREW_PREFIX="/opt/homebrew"
else
    info "Intel (x86_64) виявлено."
    BREW_PREFIX="/usr/local"
fi

# ── Homebrew ─────────────────────────────────────────────────────────────── #
step "Перевірка Homebrew"
if command -v brew &>/dev/null; then
    success "Homebrew вже встановлено: $(brew --version | head -1)"
else
    warn "Homebrew не знайдено."
    read -r -p "  Встановити Homebrew зараз? [y/N] " REPLY; echo ""
    if [[ "${REPLY}" =~ ^[Yy]$ ]]; then
        /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
        eval "$("${BREW_PREFIX}/bin/brew" shellenv)"
        success "Homebrew встановлено."
    else
        error "Homebrew потрібен. Встановіть з https://brew.sh та запустіть знову."
        exit 1
    fi
fi
eval "$(brew shellenv 2>/dev/null || true)"

# ── libusb ───────────────────────────────────────────────────────────────── #
step "Встановлення libusb"
brew list libusb &>/dev/null && success "libusb вже встановлено." || {
    brew install libusb && success "libusb встановлено."
}

# ── librtlsdr (v5-сумісна збірка з вихідного коду) ───────────────────────── #
step "Перевірка librtlsdr (RTL-SDR v5)"

check_rtlsdr_v5() {
    python3 -c "
import ctypes, sys
try:
    lib = ctypes.CDLL('${BREW_PREFIX}/lib/librtlsdr.dylib')
    _ = lib.rtlsdr_set_dithering
    print('OK')
except Exception:
    sys.exit(1)
" 2>/dev/null
}

build_rtlsdr_from_source() {
    info "Збірка librtlsdr з вихідного коду (потрібна для RTL-SDR v5)..."
    brew install cmake 2>/dev/null || true
    brew uninstall --ignore-dependencies rtl-sdr librtlsdr 2>/dev/null || true
    local TMPDIR
    TMPDIR=$(mktemp -d)
    git clone https://github.com/librtlsdr/librtlsdr.git "${TMPDIR}" --depth=1
    mkdir -p "${TMPDIR}/build"
    cmake -S "${TMPDIR}" -B "${TMPDIR}/build" \
        -DCMAKE_INSTALL_PREFIX="${BREW_PREFIX}" \
        -DINSTALL_UDEV_RULES=OFF \
        -DCMAKE_BUILD_TYPE=Release \
        -DLIBUSB_INCLUDE_DIR="${BREW_PREFIX}/include/libusb-1.0" \
        -DLIBUSB_LIBRARIES="${BREW_PREFIX}/lib/libusb-1.0.dylib"
    make -C "${TMPDIR}/build" -j"$(sysctl -n hw.logicalcpu)"
    make -C "${TMPDIR}/build" install
    rm -rf "${TMPDIR}"
    success "librtlsdr зібрано та встановлено."
}

if check_rtlsdr_v5; then
    success "librtlsdr вже v5-сумісна."
else
    warn "librtlsdr відсутня або стара версія. Збираємо з вихідного коду..."
    build_rtlsdr_from_source || warn "Збірка не вдалась — тільки --mock режим буде доступний."
fi

# ── Python ───────────────────────────────────────────────────────────────── #
step "Пошук Python 3.${MIN_PYTHON_MINOR}+"

find_python() {
    for cmd in python3.12 python3.11 python3; do
        command -v "${cmd}" &>/dev/null || continue
        local maj ver
        maj=$("${cmd}" -c "import sys; print(sys.version_info.major)" 2>/dev/null) || continue
        ver=$("${cmd}" -c "import sys; print(sys.version_info.minor)" 2>/dev/null) || continue
        [[ "${maj}" -eq 3 && "${ver}" -ge ${MIN_PYTHON_MINOR} ]] && echo "${cmd}" && return 0
    done
    return 1
}

if PYTHON_CMD=$(find_python); then
    success "Знайдено: $("${PYTHON_CMD}" --version) (${PYTHON_CMD})"
else
    warn "Python 3.${MIN_PYTHON_MINOR}+ не знайдено."
    read -r -p "  Встановити Python 3.12 через Homebrew? [y/N] " REPLY; echo ""
    if [[ "${REPLY}" =~ ^[Yy]$ ]]; then
        brew install python@3.12
        PYTHON_CMD="${BREW_PREFIX}/bin/python3.12"
        success "Python 3.12 встановлено."
    else
        error "Python 3.${MIN_PYTHON_MINOR}+ потрібен."
        exit 1
    fi
fi

# ── Віртуальне середовище ────────────────────────────────────────────────── #
step "Створення Python-середовища"
mkdir -p "${INSTALL_DIR}"
if [[ -d "${VENV_DIR}" ]]; then
    warn "Існуюче venv знайдено."
    read -r -p "  Перестворити? [y/N] " REPLY; echo ""
    [[ "${REPLY}" =~ ^[Yy]$ ]] && rm -rf "${VENV_DIR}" && info "Видалено старе venv."
fi
[[ ! -d "${VENV_DIR}" ]] && "${PYTHON_CMD}" -m venv "${VENV_DIR}" && success "venv створено."

source "${VENV_DIR}/bin/activate"
VENV_PIP="${VENV_DIR}/bin/pip"
VENV_PYTHON="${VENV_DIR}/bin/python"

step "Оновлення pip та інструментів збірки"
"${VENV_PIP}" install --upgrade pip setuptools wheel build
success "Готово."

# ── Встановлення SpaceRadio ──────────────────────────────────────────────── #
step "Встановлення SpaceRadio з вихідного коду"
export DYLD_LIBRARY_PATH="${BREW_PREFIX}/lib:${DYLD_LIBRARY_PATH:-}"
"${VENV_PIP}" install "${SRC_DIR}"
success "SpaceRadio встановлено."

step "Встановлення Python-бібліотеки для RTL-SDR"
"${VENV_PIP}" install pyrtlsdr pyrtlsdrlib || warn "pyrtlsdr не вдалось встановити — тільки --mock режим."

# ── Перевірка ────────────────────────────────────────────────────────────── #
step "Перевірка встановлення"
"${VENV_PYTHON}" -c "import skao_trt; print('[OK] skao_trt імпортовано')" && success "OK." || warn "Перевірка неоднозначна."

# ── Лаунчер ──────────────────────────────────────────────────────────────── #
step "Створення лаунчера"
cat > "${LAUNCHER}" << LAUNCHER_SCRIPT
#!/bin/bash
# SpaceRadio launcher
BREW_PFX=\$(brew --prefix 2>/dev/null || echo "${BREW_PREFIX}")
export DYLD_LIBRARY_PATH="\${BREW_PFX}/lib:\${DYLD_LIBRARY_PATH:-}"
source "${VENV_DIR}/bin/activate"
EXTRA_ARGS="\$@"
if [[ "\${EXTRA_ARGS}" != *"--no-mock"* && "\${EXTRA_ARGS}" != *"--mock"* ]]; then
  echo "[SpaceRadio] Демо-режим (--mock). Для реального обладнання: --no-mock"
  exec skao-trt --language Українська --mock "\$@"
else
  EXTRA_ARGS="\${EXTRA_ARGS//--no-mock/}"
  exec skao-trt --language Українська \${EXTRA_ARGS}
fi
LAUNCHER_SCRIPT
chmod +x "${LAUNCHER}"
success "Лаунчер: ${LAUNCHER}"

step "Створення SpaceRadio.command (подвійний клік)"
cat > "${COMMAND_FILE}" << COMMAND_SCRIPT
#!/bin/bash
osascript -e 'tell application "Terminal" to activate' 2>/dev/null || true
BREW_PFX=\$(brew --prefix 2>/dev/null || echo "${BREW_PREFIX}")
export DYLD_LIBRARY_PATH="\${BREW_PFX}/lib:\${DYLD_LIBRARY_PATH:-}"
source "${VENV_DIR}/bin/activate"
cd "${INSTALL_DIR}"
echo "[SpaceRadio] Запуск у демо-режимі. Для реального обладнання запустіть з --no-mock"
skao-trt --language Українська --mock
COMMAND_SCRIPT
chmod +x "${COMMAND_FILE}"
success ".command: ${COMMAND_FILE}"

if [[ -d "${DESKTOP}" ]]; then
    echo ""
    read -r -p "  Додати ярлик на Робочий стіл? [y/N] " REPLY; echo ""
    if [[ "${REPLY}" =~ ^[Yy]$ ]]; then
        cp "${COMMAND_FILE}" "${DESKTOP}/SpaceRadio.command"
        chmod +x "${DESKTOP}/SpaceRadio.command"
        success "Ярлик на робочому столі створено."
    fi
fi

deactivate 2>/dev/null || true

echo ""
echo -e "${BOLD}${GREEN}"
echo "  ╔══════════════════════════════════════════════════════════════╗"
echo "  ║             SpaceRadio встановлено! 🎉                       ║"
echo "  ╚══════════════════════════════════════════════════════════════╝"
echo -e "${NC}"
echo ""
echo -e "${BOLD}  Запуск:${NC}"
echo "    ${LAUNCHER}           # демо-режим"
echo "    ${LAUNCHER} --no-mock  # реальне обладнання"
echo ""
echo -e "${BOLD}  Або подвійний клік у Finder:${NC}"
echo "    ${COMMAND_FILE}"
echo ""
